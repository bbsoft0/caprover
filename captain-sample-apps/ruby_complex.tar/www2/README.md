# Rails5BlazingTemplate

Rails 5.1 Blazing Fast Template 

## Getting Started

Install the project on your local machine for development and testing purposes. 
See deployment for notes on how to deploy the project on a live system.

## Prerequisites

Ruby - version 2.4.1. Minimum version recommended: ruby 2.2.2

## Deployment

Create the folders:
 /tmp/sockets
 /tmp/pids
 
Project starts as a process directly.

## License

This project is licensed under the MIT License
